import React, { Component,  } from 'react';

class Buscador extends Component{
// nos va a permitir leer los valors de los inputs con react 
    busquedaRef = React.createRef(); 

    obtenerDatos = (e) =>{
// previene por defaul valor en el navegador.
        e.preventDefault();
//tomamos el valor del input 
        const  obt = this.busquedaRef.current.value;
// lo enviamos al compoente
        this.props.datosBusqueda(obt);

    }
    render() {
        return(
            <form onSubmit={this.obtenerDatos}>
                <div className='row'>
                     
                    <div className='form-group col-md-8'>
                        <input ref={this.busquedaRef} type='text' className="form-control
                         form-control-lg"
                         placeholder='busca tu pelicula. Ejemplo: AVengers'/>
                    </div>
                    <div className='form-group col-md-4'>
                        <input type='submit' className="btn btn-lg btn-danger btn-block"
                         value='buscar'/>
                    </div>
                </div>
            </form>
        );
    }
}

export default Buscador;