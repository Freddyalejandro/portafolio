import { Component } from 'react';
import './App.css';
//import FormSearch from './componente/formSearch';
import Buscador from './compenentes/Buscador'
import Resultado from './compenentes/resultado';

class App extends Component {
  //construimos con objeto llamada state
  // este state me permite tener el aceso al estado e imprimirlo 
  constructor (props){
    super(props)
    this.state ={
      films:"",
      portada: []
       
    }
  }

  consultarApi =()=>{
    const URL =`https://imdb8.p.rapidapi.com/auto-complete?q=${this.state.films}&per_page=20`
    const op ={
      headers: {
        'X-RapidAPI-Key': '9f6d3c0ed8mshd5ae8ecb89ed3a4p142371jsn5bb3f44c2b79',
        'X-RapidAPI-Host': 'imdb8.p.rapidapi.com'
      }
    };
    fetch(URL,op)
    .then(response => response.json())
    .then(response => this.setState({portada : response}))
    .catch(err => console.error(err));
  }
// este funcion va a mostar los datos que ingresamos, recibe un prop que sera el mismo
// que al cual le dimos en el constructor
  datosBusqueda = (films) =>{
    this.setState({
      films
    }, ()=> {
      this.consultarApi();
    })
    
  }

  render(){
    return (
    <div className="App container">
      <div className="jumbotron">
        <p className="lead text-center">Buscar pelicula PRUEBA</p>
        <Buscador
       datosBusqueda= {this.datosBusqueda}
       />
      </div>
       <Resultado
       portada = {this.state.portada}
       />
    </div>
    
    );
  }
}

export default App;